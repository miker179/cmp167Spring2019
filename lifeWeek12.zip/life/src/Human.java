/*
 * Author: Michael Rivera
 * desc:
 * Created  : 5.12.19 edit
 */
public class Human {
	// WE have achieved encapsulation by having our instance variable private
	// We then will provide setters and getters to provide access
	private int food; //They belong to the object, they are instance variables
	private int age;
	private String name;
	private double wealth;
	private double hunger;
	private boolean hasVehicle;
	private Vehicle[] vehicles; //array of vehicles
	
	public Human() {//Constructor new Human();
		this.age = 0;
		this.name = "";
		this.wealth = 0.0;
		this.hasVehicle = false;
		this.hunger = 5.0;
		this.food = 5;
		this.vehicles = new Vehicle[100];
	}
	
	public Human(String name, int age) { // overloaded constructor
		this.age = age;
		this.name = name;
		this.wealth = 0.0;
		this.hasVehicle = false;
		this.hunger = 5.0;
		this.food = 5;
		this.vehicles = new Vehicle[100];
	}
	//getter: RETURNS VALUE OF INSTANCE VARIABLE
	public int getAge() {
		return this.age;
	}
	
	public String getName() {
		return this.name;
	}
	//setter: CHANGES THE VALUES OF INSTANCE VARIABLES
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	// The toString method provides a string  representation of the object
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Human:[ name " + getName() + ", age:" + getAge() + " , wealth: " + this.wealth + "$]";
	}
	
	public int numberOfVehicles() {
		int total = 0;
		for (int i = 0; i < vehicles.length; i++) {
			if(vehicles[i] != null)
				total++;
			else
				break;
		}
		return total;
	}
	
	public void eat() {
		System.out.println("Eating Command");
		if(food >= 4.5) { 
			hunger -= 1.0;
			food -= 1;
			System.out.println("Yummy");
		}
		else 
			System.out.println("Not enough food please buy food");
	}
	
	public void eat(int food) {//overloaded method
		hunger -= food/4.5;
	}
	
	public void grow() {
		age++;
	}
	
	public void work() {
		System.out.println("Working Command");
		if(hunger < 5) {
			wealth += 10.5;
			hunger += 0.5;
			System.out.println("Whoah, I work a lot");
		}
		else
			System.out.println("Too hungry to work");
	}
	
	public void buyFood() {
		System.out.println("Eating Commmand");
		if(wealth > 5) {
			wealth -= 5.25;
			food++;
			System.out.println("Yoohooo! I bought some food");
		} else {
			System.out.println("No money, please work!");
		}
	}
}
