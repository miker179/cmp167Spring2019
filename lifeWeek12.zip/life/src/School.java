/*
 * Author: Michael Rivera
 * Desc:
 * Date: 4.16.19
 */
public class School {
	public String name;
	public String classroom;
	public String location;
	public boolean isPublic;
	public boolean isOpen;
	
	public void open() {
		
	}
	
	public void close() {
		
	}
}
