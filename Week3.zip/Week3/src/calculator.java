/*
 * file  : calculator.java
 * Author: Michael Rivera
 * Date  : 2.07.19
 * desc  : This program implements quadratic formula
 */

import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		
		System.out.println("\t\tWelcome to Quadratic 3000");
		System.out.println("This program implements quadratic formula");
		
		Scanner scnr= new Scanner(System.in);
		double a;
		double b;
		double c;
		double root1;
		double root2;
		
		System.out.println("Enter a: ");
		a = scnr.nextDouble();
		
		System.out.println("Enter b: ");
		b = scnr.nextDouble();
		
		System.out.println("Enter c: ");
		c = scnr.nextDouble();
		
		double discriminent;
		discriminent = (b*b) - (4 * a * c);
		
		root1 = (-b + Math.sqrt(discriminent))/2.0 * a;
		root2 = (-b - Math.sqrt(discriminent))/2.0 * a;
		
		System.out.println("Root1 is: " + root1);
		System.out.println("Root2 is: " + root2);
			
	}

}
