/*
 * Review.java
 * 3.19.19
 * Review for midterm
 */
import java.util.Scanner;

public class Review {
	static Scanner keyboard = new Scanner(System.in);
	
	public static void greet() {
		
		System.out.println("\t\tWelcome");
		
	}
	
	public static void title() {
	
	
		
		System.out.println("What's your name");
		String name = keyboard.nextLine();
		greet();
		if (name.endsWith("e") || name.endsWith("a")) {
			
			System.out.println("Miss " + name);
		} else {
			System.out.println("Mister" + name);
			
		}
		
	}
	public static void greetPeople(int numOfPeople) {
		for (int i = 0; i < numOfPeople; i++) {
			title();
		}
	}
	public static void main(String[] args) {
		System.out.println("Enter number of people:");
		int num = keyboard.nextInt();
		greetPeople(num);
	}
	
}
