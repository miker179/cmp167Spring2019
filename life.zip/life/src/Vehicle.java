/*
 * Author: Michael Rivera
 * Desc: 
 * Date: 4.16.19
 */
public class Vehicle {
	public String color;
	public String brand;
	public int wheels;
	
	public void run() {
		if (wheels > 1) 
			System.out.println("Broom, broom!");
	}

	public void stop() {
		if (wheels <= 1)
			System.out.println("tchh, car won't move");
	}
}
