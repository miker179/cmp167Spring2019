
public class Vehicle {

}
