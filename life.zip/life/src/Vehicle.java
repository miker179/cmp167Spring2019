import java.util.Scanner;

/*
 * Author: Michael Rivera
 * Desc: 
 * Date: 4.30.19
 */
public class Vehicle {
	public String color;
	public String brand;
	public int wheels;
	
	Scanner input = new Scanner(System.in);
	
	public void run() {
		System.out.println("Enter car brand");
		brand = input.nextLine();
		System.out.println("Enter color");
		color = input.nextLine();
		if (wheels > 1) 
			System.out.println("Broom, broom! Your " + color + " " 
					+ brand + " car is ready to go.");
	}

	public void stop() {
		System.out.println("Enter car brand");
		brand = input.nextLine();
		System.out.println("Enter color");
		color = input.nextLine();
		if (wheels <= 1)
			System.out.println("tchh, your "+ color + " " + brand + " won't move");
	}
}
