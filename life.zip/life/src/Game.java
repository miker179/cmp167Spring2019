
public class Game {

	public static void main(String[] args) {
		Human person1 = new Human(); // Creating;
		
//		System.out.println("Hunger: " + person1.hunger);
//		System.out.println("Food: " + person1.food);
//		System.out.println("Eating Command:");
//		person1.eat();
//		System.out.println("Eating Command:");
//		person1.eat();
//		System.out.println("Hunger: " + person1.hunger);
//		System.out.println("Food: " + person1.food);
//		System.out.println("Buying Command");
//		person1.buyFood();
//		System.out.println("Working Command");
//		person1.work();
//		System.out.println("Buying Command");
//		person1.buyFood();
//		System.out.println("Working Command");
//		person1.work();
//		System.out.println("Working Command");
//		person1.work();
//		System.out.println("Eating Command:");
//		person1.eat();
//		System.out.println("Working Command");
//		person1.work();
//		System.out.println("Working Command");
//		person1.work();
//		System.out.println("Eating Command:");
//		person1.eat();
//		System.out.println("Eating Command:");
//		person1.eat();
//		System.out.println("Buying Command");
//		person1.buyFood();
//		System.out.println("Buying Command");
//		person1.buyFood();
//		person1.eat();
//		person1.eat();
//		person1.eat();
//		person1.work();
//		person1.work();
//		person1.work();
//		person1.buyFood();
	}

}
