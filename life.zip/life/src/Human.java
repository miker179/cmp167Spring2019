/*
 * Author: Michael Rivera
 * desc:
 * Created  : 4.11.19
 */
public class Human {
	//instance
	public int food;
	public int age;
	public String name;
	public double wealth;
	public double hunger;
	public boolean hasVehicle;
	
	public Human() {//Constructor new Human();
		this.age = 0;
		this.name = "";
		this.wealth = 0.0;
		this.hasVehicle = false;
		this.hunger = 5.0;
		this.food = 5;
	}
	
	public void eat() {
		System.out.println("Eating Command");
		if(food >= 4.5) { 
			hunger -= 1.0;
			food -= 1;
			System.out.println("Yummy");
		}
		else 
			System.out.println("Not enough food please buy food");
	}
	
	public void grow() {
		age++;
	}
	
	public void work() {
		System.out.println("Working Command");
		if(hunger < 5) {
			wealth += 10.5;
			hunger += 0.5;
			System.out.println("Whoah, I work a lot");
		}
		else
			System.out.println("Too hungry to work");
	}
	
	public void buyFood() {
		System.out.println("Eating Commmand");
		if(wealth > 5) {
			wealth -= 5.25;
			food++;
			System.out.println("Yoohooo! I bought some food");
		} else {
			System.out.println("No money, please work!");
		}
	}
}
