/*
 * Author: Michael Rivera
 * desc:
 * Created  : 4.11.19
 */
public class Human {
	//instance
	public int food;
	public int age;
	public String name;
	public double wealth;
	public double hunger;
	public boolean hasVehicle;
	
	
	
	public void eat() {
		if(food > 0) 
			hunger--;
		else 
			System.out.println("Not enough food please buy food");
	}
	
	public void grow() {
		age++;
	}
	
	public void work() {
		if(hunger < 5)
			wealth += 15.5;
		else
			System.out.println("Too hungry to work");
	}
	
	public void buyFood() {
		if(wealth > 5) {
			wealth -= 5.25;
			food++;
		} else {
			System.out.println("No money, please work!");
		}
	}
}
