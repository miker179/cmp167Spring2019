
public class School {

}
