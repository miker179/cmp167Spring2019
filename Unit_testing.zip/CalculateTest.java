package week9;

import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class CalculateTest {
	
	@BeforeClass
	public static void greet() {
		System.out.println("Before Everything");
	}
	
	@Before
	public void perMethod() {
		System.out.println("Before each test");
	}
	
	@After
	public void afterMethod() {
		System.out.println("After each test");
	}
	
	@Test
	public void test() {
		assertEquals(0 , Testing.multiply(0, 1));
		System.out.println("Test 1");
	}
	
	@Test
	public void test1() {
		assertEquals(1 , Testing.multiply(1, 1));
		System.out.println("Test 2");
	}
	
	@Test
	public void test2() {
		assertEquals(2.0 , Testing.multiply(1.0, 2.0), 0.0001);
		System.out.println("Test 3");
	}

}
