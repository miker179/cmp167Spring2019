/*
 * Author: Michael Rivera
 * Date: Using arrays
 * Created:
 */
public class Calculate {

	public static int sumList(int[] list) {
		int total = 0;
		for(int i = 0; i < list.length; i++) {
			total += list[i];
		}
		return total;
	}
	
	public static int avgList(int[] iArray) {
		int avg = 0;
		
		avg = sumList(iArray)/iArray.length;
		return avg;
	}
	
	public static int oddElements(int[] iArray) {
		int total = 0;
		for(int i = 0; i < iArray.length; i++) {
			if(iArray % 2 == 1)
				return total + i;
		}
	}
	
	public static void main(String[] args) {
		int[] iArray1 = {2,45,45,34,21,32};
		int[] iArray2 = {5,52,34,32,12,21};
		int sum2 = sumList(iArray2);
		int avg2 = avgList(iArray2);
		
		System.out.printf("The sum of all elements in iArray1 is %d \nand the average is %d\n",
				sumList(iArray1), avgList(iArray1));
		System.out.printf("The sum of all elements in iArray1 is %d \nand the average is %d\n",
				sum2, avg2);
	}
}
