/*
 * Author:Michael Rivera
 * Date  :2.21.19
 * Desc  :UserAge
 */
package week4;

import java.util.Scanner;

public class Agetitle {

	public static void main(String[] args) {
		Scanner scnr = new Scanner (System.in);
		int userAge;
		
		System.out.println("Enter age: ");
		userAge = scnr.nextInt();
		
		if (userAge > 25) {
			System.out.println(userAge + " Adult");
		}
		else if (userAge >= 19 && userAge <= 25) {
			System.out.println(userAge + " young adult");
			
		}
		else {
			System.out.println(userAge + " teen");
		}
	}	
}
