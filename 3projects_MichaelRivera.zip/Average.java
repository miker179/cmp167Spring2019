/*
 * Average class
 * Name: Michael Rivera
 * Date: 03.7.19
 */
import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
	     	 int n,num,sum=0, i; 
	  
	         System.out.print("Enter How Many Numbers : ");//input 
	         n =input.nextInt(); //read total numbers 
	         System.out.print("Enter the Numbers :"); 
	         for(i=1;i<=n; i++) 
	             { 
	                  num=input.nextInt(); //input number 
	                  sum += num; 
	             } 
	          double average=(double)sum/n; 
	          System.out.println("Average of " + n + " Numbers = " + average); 
	          
	      } 

} 
