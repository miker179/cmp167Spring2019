/*
 * Factorial class
 * Name: Michael Rivera
 * Date: 03.7.19
 */
import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
			 int i,fact=1;  
			 int number;//It is the number to calculate factorial
			 
			 System.out.println("ENTER NUMBER: ");
			 number = input.nextInt();
			 
			 for(i=1;i<=number;i++){    
			      fact=fact*i;    
			  }    
			  System.out.println("Factorial of "+number+" is: "+fact);    
	  
	}

}
