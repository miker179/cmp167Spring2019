/*
 * Power class
 * Name: Michael Rivera
 * Date: 03.7.19
 */
import java.util.Scanner;

public class Power {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("\t\t Welcome to Power");
		System.out.println("\tThis program calculates teh frist nth powers of 2");

		System.out.println("Please enter value of n:");
		int n = input.nextInt();

		int power = 1;
		System.out.println("");
		for (int i = 1; i <= n; i++) {
			power = power * 2;
			System.out.println(power);
		}
	}

}
