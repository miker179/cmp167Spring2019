/*
 * Author: Michael Rivera
 * Date: 2.07.19
 */

import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		Scanner scnr= new Scanner(System.in);
		int num1;
		int num2;
		int num3;
		int average;
		
		System.out.println("Enter the number: ");
		num1 = scnr.nextInt();
		num2 = scnr.nextInt();
		num3 = scnr.nextInt();
		
		average = (num1+num2+num3)/3;
		System.out.println("The Average is: " + average );
			
	}

}
