package week9;

public class DMV {
	
	public static void generateDL(int age, boolean testPass) {
		
		if (age >= 17 && testPass) {
			System.out.println("DL generated");
		} else
			System.out.println("CANNOT GENERATE DL");
	}
	
	public static int calculateExpirationDate(int yearsGenerated) {
		
		return yearsGenerated + 10;
	}
	
	public static void main(String[] args) {
		generateDL(16,false);
		System.out.println(calculateExpirationDate(2005));
	}
}

