package week9;

public class Person {
	
	String name = "";
	int age;
	char gender;
	
	//constructer, has the same name as the class
	public Person(String name, int age, char gender) {
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
}
