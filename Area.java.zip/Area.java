/*
 * Area.java
 * Michael Rivera
 * This program has area function/method
 */
import java.util.Scanner;

public class Area {
	//scanner object
	static Scanner  input = new Scanner (System.in);
	/*
	 * rectArea : void
	 * Inputs: width and length
	 * process: area = width * length
	 * output: area
	 */
	public static void rectArea() {
		
		int width;
		int length;
		int area;
		//input
		System.out.println("Enter the width: ");
		width = input.nextInt();
		
		System.out.println("Enter the length: ");
		length = input.nextInt();
		//calculations
		area = width * length;
		//output
		System.out.println("The rectangle area is " + area);

	}
	//Circle Area
	/*
	 * circArea
	 * input: radius
	 * process: area = pi * radius^2
	 * output: area
	 */
	public static void circArea() {
		
		int radius;
		double area;
		//input
		System.out.println("Enter radius:");
		radius = input.nextInt();
		// calculation
		area = Math.PI * Math.pow(radius, 2);
		
		System.out.printf("The circle area: %.2f\n", area);
	}
	//Triangle area
	/*
	 * triArea
	 * input:height, base
	 * process:area = (base * height)/2
	 * output: area
	 */
	public static void triArea() {
		
		double height;
		double base;
		double area;
		
		System.out.println("Enter height: ");
		height = input.nextDouble();
		System.out.println("Enter base: ");
		base = input.nextDouble();
		
		area = (height * base) / 2;
		
		System.out.printf("The triangle area is : %.2f", area);
	}
	//for debugging
	public static void main(String[] args) {
		circArea();
		triArea();
	}

}
