/*
 * Area.java
 * Michael Rivera
 * This program has area function/method
 * modified: 3.14.19
 */
import java.util.Scanner;

public class Area {
	//scanner object
	static Scanner  input = new Scanner (System.in);
	/*
	 * rectArea : void
	 * Inputs: width and length
	 * process: area = width * length
	 * output: area
	 */
	public static void rectArea() {
		
		int width;
		int length;
		int area;
		//input
		System.out.println("Enter the width: ");
		width = input.nextInt();
		
		System.out.println("Enter the length: ");
		length = input.nextInt();
		//calculations
		area = width * length;
		//output
		System.out.println("The rectangle area is " + area);

	}
	//Circle Area
	/*
	 * circArea
	 * input: radius
	 * process: area = pi * radius^2
	 * output: area
	 */
	public static void circArea() {
		
		int radius;
		double area;
		//input
		System.out.println("Enter radius:");
		radius = input.nextInt();
		// calculation
		area = Math.PI * Math.pow(radius, 2);
		
		System.out.printf("The circle area: %.2f\n", area);
	}
	//Triangle area
	/*
	 * triArea
	 * input:height, base
	 * process:area = (base * height)/2
	 * output: area
	 */
	public static void triArea() {
		
		double height;
		double base;
		double area;
		
		System.out.println("Enter height: ");
		height = input.nextDouble();
		System.out.println("Enter base: ");
		base = input.nextDouble();
		
		area = (height * base) / 2;
		
		System.out.printf("The triangle area is : %.2f", area);
	}
	/*
	 * getRecArea: int
	 * params: width: int, length:int
	 * calculates:rectangle area
	 */
	public static int getRecArea(int width, int length) {
		return width * length;
	}
	/*
	 * getTriArea: double
	 * params: base: double, height: double
	 * calculates: Triangle area
	 */
	public static double getTriArea(double base, double height) {
		return (base * height) / 2;
	}
	/*
	 * getCircArea: double
	 * params: radius: double
	 * calculates: circle area
	 */
	public static double getCircArea(double radius) {
		return Math.PI * Math.pow(radius, 2);
	}
	//for debugging
	public static void main(String[] args) {
		circArea();
		triArea();
		System.out.println("Enter width an length\n");
		int width = input.nextInt();
		int length = input.nextInt();
		
		int area = getRecArea(width, length);
		
		System.out.println("Area: " + area);
	}

}
